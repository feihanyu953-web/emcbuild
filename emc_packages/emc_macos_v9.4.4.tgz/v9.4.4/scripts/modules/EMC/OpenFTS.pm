#!/usr/bin/env perl
#
#  module:	EMC::OpenFTS.pm
#  author:	Pieter J. in 't Veld
#  date:	June 2, 2026.
#  purpose:	Empty structure routines; part of EMC distribution
#
#  Copyright (c) 2004-2026 Pieter J. in 't Veld
#  Distributed under GNU Public License as stated in LICENSE file in EMCroot
#  directory
#
#  general members:
#    commands		HASH	structure commands
#
#    identity		HASH
#      author		STRING	module author
#      date		STRING	latest modification date
#      version		STRING	module version
#
#    set		HASH
#      commands		FUNC	commands initialization
#      defaults		FUNC	defaults initialization
#      options		FUNC	options interpretation
#      flag		HASH	control flags
#        indicator	BOOLEAN	include "openfts_" indicator in commands
#        commands	BOOLEAN	include commands in $root->{options}
#
#  specific members:
#    context		HASH	optional settings
#    flag		HASH	optional flags
#
#  notes:
#    20260602	Inception of v1.0
#

package EMC::OpenFTS;

use strict;
use Exporter;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

$VERSION = "1.0";
@ISA = qw(Exporter);
#@EXPORT = qw(&func);		# export of functions, e.g. func
				# 'sub import' is executed upon 'use EMC::OpenFTS'
#use vars qw($var %hash);	# available as $EMC::IO::var and %EMC::IO::hash

use JSON;

use EMC::Common;
use EMC::Element;
use EMC::Math;
use EMC::Options;


# defaults

$EMC::OpenFTS::Identity = {
  author	=> "Pieter J. in 't Veld",
  date		=> "June 2, 2026",
  version	=> "1.0"
};


# construct

sub construct {
  my $openfts = EMC::Common::hash(EMC::Common::element(shift(@_)));
  my $attr = EMC::Common::attributes(@_);
 
  set_functions($openfts, $attr);
  set_defaults($openfts);
  set_commands($openfts);
  return $openfts;
}


# initialization

sub set_defaults {
  my $openfts = EMC::Common::hash(shift(@_));
  my $root = ref(@_[0]) eq "HASH" ? shift(@_) : undef;
  my $backwards = EMC::Common::element($root, "global", "flag", "backwards");

  $openfts->{context} = EMC::Common::attributes(
    EMC::Common::hash($openfts, "context"),
    {
      binsize		=> 0.1,
      focus		=> {
	clusters	=> {},
	groups		=> {},
	sites		=> {}
      }
    }
  );
  $openfts->{flag} = EMC::Common::attributes(
    EMC::Common::hash($openfts, "flag"),
    {
      active		=> 0,
      compress		=> 0,
      convolute		=> 1,
      normalize		=> 1,
      write		=> 0
    }
  );
  $openfts->{defaults} = EMC::Common::attributes(
    EMC::Common::hash($openfts, "defaults"),
    {
      cell => {
	cell_scale => 1,
	length_unit => "Rg",
      },
      driver => {
	dt => 1,
	field_updater => {
	  adaptive_timestep => bless( do{\(my $o = 0)}, 'JSON::PP::Boolean' ),
	  lambdas => undef,			# [1, ...] nmasses array of ones
	  type => "EMPEC",
	  update_order => "simultaneous",
	},
	nsteps => 4000,
	output_freq => 50,
	stop_tolerance => "1e-05",
	type => "SCFT",
      },
      fieldlayout => {
	npw => "auto",
	random_seed => 1,
      },
      include => {
	file => undef				# set to project_emc.json
      },
      model => {
	Nref => 1,
	bref => 1,
	initfields => {
	  field_type => "exchange",
	  file => undef				# set to project_emc.dat
	},
	type => "ChiMultiSpecies"		# needs "chi_array" from EMC
      },
      # molecules => {},			# from EMC
      monitors => {},
      operators => {
	CellStress => {
	  averaging_type => "none",
	},
	Hamiltonian => {
	  averaging_type => "none",
	},
	SpeciesFields => {
	  averaging_type => "none",
	},
      },
      output => {
	field_errors => {
	  file => "error.dat",
	},
	fields => {
	  exchange_fields => {
	    file => undef,			# set to project_fields.dat
	    save_history => do{my $o}
	  },
	  file_format => "plain_text",
	  species_densities => {
	    file => undef,			# set to project_density.dat
	    save_history => do{my $o}
	  },
	},
	scalar_operators => {
	  file => "operators.dat",
	},
      },
      # species => {}				# from EMC
    }
  );
  $openfts->{identity} = EMC::Common::attributes(
    EMC::Common::hash($openfts, "identity"),
    $EMC::OpenFTS::Identity
  );
  return $openfts;
}


sub transfer {
  my $openfts = EMC::Common::hash(shift(@_));
  my $flag = EMC::Common::element($openfts, "flag");
  my $context = EMC::Common::element($openfts, "context");
  
  EMC::Element::transfer(shift(@_),
    [\$::EMC::OpenFTS{dummy},		\$context->{dummy}],
  );
}


sub set_context {
  my $openfts = EMC::Common::hash(shift(@_));
  my $root = EMC::Common::hash(shift(@_));
  my $global = EMC::Common::element($root, "global");
  my $field = EMC::Common::element($root, "fields", "field");
  my $units = EMC::Common::element($global, "units");
  my $flag = EMC::Common::element($openfts, "flag");
  my $context = EMC::Common::element($openfts, "context");
}


sub set_commands {
  my $openfts = EMC::Common::hash(shift(@_));
  my $set = EMC::Common::element($openfts, "set");
  my $context = EMC::Common::element($openfts, "context");
  my $flag = EMC::Common::element($openfts, "flag");
  my $indicator = defined($set) ? $set->{flag}->{indicator} : 1;
  my $depricated = defined($set) ? $set->{flag}->{depricated} : 1;
  my $flag_depricated =  $indicator ? 0 : $depricated;
  my $pre = $indicator = $indicator ? "openfts_" : "";

  $context->{depricated} = $flag_depricated;
  $openfts->{commands} = EMC::Common::hash($openfts, "commands");
  while (1) {
    my $commands = {
      openfts		=> {
	comment		=> "OpenFTS settings",
	set		=> \&EMC::OpenFTS::set_options,
	default		=> EMC::Hash::text($flag)
      },
      $indicator."binsize"	=> {
	comment		=> "Set voxel bin size",
	set		=> \&EMC::OpenFTS::set_options,
	default		=> $context->{binsize}
      },
      $indicator."compress"	=> {
	comment		=> "Compress data file",
	set		=> \&EMC::OpenFTS::set_options,
	default		=> EMC::Math::boolean($flag->{compress})
      },
      $indicator."convolute"	=> {
	comment		=> "Toggle convolution of volume over voxels",
	set		=> \&EMC::OpenFTS::set_options,
	default		=> EMC::Math::boolean($flag->{convolute})
      },
      $indicator."normalize"	=> {
	comment		=> "Toggle normalization of voxels",
	set		=> \&EMC::OpenFTS::set_options,
	default		=> EMC::Math::boolean($flag->{normalize})
      }
    };

    if ($flag_depricated) {
      foreach (keys(%{$commands})) {
	$commands->{$_}->{original} = $pre.$_;
      }
    }
    EMC::Options::set_command(
      $openfts->{commands} = EMC::Common::attributes(
	$openfts->{commands}, $commands
      ),
      {
	set		=> \&EMC::OpenFTS::set_options
      }
    );
    last if ($indicator eq "" || !$depricated);
    $flag_depricated = 1;
    $indicator = "";
  }
  
  EMC::Options::set_command(
    $openfts->{items} = EMC::Common::attributes(
      EMC::Common::hash($openfts, "items"),
      {
	openfts		=> {		# added "openfts" to verbatim in
	}				# EMC::Script::read()
      }
    ),
    {
      chemistry		=> 1,
      environment	=> 0,
      order		=> 0,
      set		=> \&EMC::OpenFTS::set_item
    }
  );

  return $openfts;
}


sub set_options {
  my $struct = shift(@_);
  my $option = EMC::Common::element($struct, "option");
  my $args = EMC::Common::element($struct, "args");
  my $file = EMC::Common::element($struct, "file");
  my $line = EMC::Common::element($struct, "line");
  my $root = EMC::Common::element($struct, "root");
  my $openfts = EMC::Common::element($struct, "module");
  my $context = EMC::Common::hash($openfts, "context");
  my $flag = EMC::Common::hash($openfts, "flag");
  my $set = EMC::Common::element($openfts, "set");
  my $indicator = defined($set) ? $set->{flag}->{indicator} : 1;

  $indicator = $indicator ? "openfts_" : "";
  while (1) {
    if ($option eq "openfts") {
      my $result = 0;
      my @a = split("=", $args->[0]);
      if (scalar(@a)>0 || scalar(@{$args})>0) {
	EMC::Hash::set($line, $flag, "boolean", "active", [], @{$args});
	$result = $flag->{active};
      } else {
	$result = $flag->{active} = EMC::Math::flag($args->[0]);
      }
      if ($result) {
	EMC::MD::set_flags(
	  EMC::Common::element($openfts, "parent"), "write", 0);
      }
      return $flag->{write} = $result;
    }
    if ($option eq $indicator."binsize") {
      return $flag->{binsize} = EMC::Math::eval($args->[0])->[0];
    }
    if ($option eq $indicator."compress") {
      return $flag->{compress} = EMC::Math::flag($args->[0]);
    }
    if ($option eq $indicator."convolute") {
      return $flag->{convolute} = EMC::Math::flag($args->[0]);
    }
    if ($option eq $indicator."normalize") {
      return $flag->{normalize} = EMC::Math::flag($args->[0]);
    }
    last if ($indicator eq "" || !$context->{depricated});
    $indicator = "";
  }
  return undef;
}


sub set_item {
  
  # could use EMC::Script::set_item_verbatim() instead, provided
  # no merging between several 'ITEM OPENFTS' should occur
  
  my $struct = shift(@_);
  my $root = EMC::Common::element($struct, "root");
  my $item = EMC::Common::element($struct, "item");
  my $options = EMC::Hash::arguments(EMC::Common::element($item, "options"));

  return $root if (EMC::Common::element($options, "comment"));
  
  my $module = EMC::Common::element($struct, "module");
  my $option = EMC::Common::element($struct, "option");
  my $data = EMC::Common::element($item, "data");

  $module->{verbatim} = $item;
  return $root;
}


sub set_functions {
  my $openfts = EMC::Common::hash(shift(@_));
  my $set = EMC::Common::hash($openfts, "set");
  my $write = EMC::Common::hash($openfts, "write");
  my $attr = EMC::Common::attributes(@_);
  my $flags = {commands => 1, depricated => 0, indicator => 1, items => 1};

  $set->{commands} = \&set_commands;
  $set->{context} = \&set_context;
  $set->{defaults} = \&set_defaults;
  $set->{options} = \&set_options;
  $set->{items} = \&set_items;

  $write->{emc} = \&write_emc;
  $write->{job} = \&write_job;
  $write->{script} = \&write_script;
  
  foreach (keys(%{$flags})) {
    $set->{flag}->{$_} =
      EMC::Math::flag(defined($attr->{$_}) ? $attr->{$_} : $flags->{$_});
  }
  return $openfts;
}


# functions

# OpenFTS script

sub write_script {				# <= write_lammps
  my $root = shift(@_);
  my $name = shift(@_);

  my $global = EMC::Common::element($root, "global");
  my $lammps = EMC::Common::element($root, "md", "openfts");
  my $flag = EMC::Common::element($lammps, "flag");

  return if (!defined($flag) || !$flag->{write});

  if ((-e "$name.json")&&!$global->{replace}->{flag}) {
    EMC::Message::warning(
      "\"$name.json\" exists; use -replace flag to overwrite\n");
    return;
  }

  EMC::Message::info("creating OpenFTS input script \"$name.json\"\n");

  my $stream = EMC::IO::open("$name.json", "w");
  my $stage = [
    "header", "body"
  ];
  my $write = {
    header		=> \&write_header,
    body		=> \&write_body
  };

  foreach (@{$stage}) {
    $write->{$_}->($stream, $root);
  }

  EMC::IO::close($stream);
}


sub write_header {
  return;					# no comments in standard 
						# JSON
  my $stream = shift(@_);
  my $root = shift(@_);

  my $global = EMC::Common::element($root, "global");
  my $context = EMC::Common::element($root, "md", "openfts", "context");
  my $flag = EMC::Common::element($root, "md", "openfts", "flag");

  my $identity = EMC::Common::element($global, "identity");
  my $date = EMC::Common::date_full();

  printf($stream "%s",
"# OpenFTS input script for standardized SCFT simulations
# Created by $identity->{script} v$identity->{version}, $identity->{date} as part of EMC
# on $date

");
}


sub write_body {
  my ($stream, $root) = @_[0..1];

  my $global = EMC::Common::element($root, "global");
  my $project = EMC::Common::element($global, "project", "name");
  
  my $openfts = EMC::Common::element($root, "md", "openfts");
  my $verbatim = EMC::Common::element($openfts, "verbatim");
  my $data = EMC::Common::element($verbatim, "data");

  if ($data) {
    my $json = JSON->new->allow_nonref;
    my $ptr = EMC::Hash::merge(
      EMC::Hash::copy($openfts->{defaults}),
      $json->decode(join("\n", @{$data})));

    $ptr->{include}->{file} = $project."_emc.json";
    $ptr->{model}->{initfields}->{file} = $project."_emc.dat";
    $ptr->{output}->{fields}->{exchange_fields}->{file} = $project."_fields.dat";
    $ptr->{output}->{fields}->{species_densities}->{file} = $project."_density.dat";

    printf($stream "%s", $json->canonical->pretty->encode($ptr));
  }
}


# EMC script additions

sub write_emc {
  my $lammps = shift(@_);
  my $root = shift(@_);

  my $stream = EMC::Common::element($root, "io", "stream");
  my $emc_flag = EMC::Common::element($root, "emc", "flag");
  my $global = EMC::Common::element($root, "global");
  my $field = EMC::Common::element($root, "fields", "field");
  my $context = EMC::Common::element($lammps, "context");
  my $flag = EMC::Common::element($lammps, "flag");
  my $md = EMC::Common::element($lammps, "parent");

  return if (!EMC::Common::element($flag, "active"));

  printf($stream
    "\nopenfts\t\t= {name -> output, ");
  printf($stream
    "binsize -> $context->{binsize}, ");
  printf($stream
    "seed -> seed,\n");
  printf($stream
    "\t\t   compress -> %s, ", EMC::Math::boolean($flag->{compress}));
  printf($stream
    "convolute -> %s, ", EMC::Math::boolean($flag->{convolute}));
  printf($stream
    "normalize -> %s", EMC::Math::boolean($flag->{normalize}));
  printf($stream "};\n");
}


# BASH jobs workflow additions

sub write_job {
  my $lammps = shift(@_);
  my $root = shift(@_);

  my $stream = EMC::Common::element($root, "io", "stream");
  my $global = EMC::Common::element($root, "global");
  my $context = EMC::Common::element($lammps, "context");
  my $flag = EMC::Common::element($lammps, "flag");
  my $project_name = EMC::Common::element($global, "project", "name");

  return if (!(defined($flag) && $flag->{write}));

  return;

  my $md = EMC::Common::element($root, "md", "context");
  my $md_flag = EMC::Common::element($root, "md", "flag");
  my $restart_dir = EMC::Common::element($md, "restart_dir");
  my $restart_name = "\${restart_dir}/*/*.restart?";
  my $restart_file = $md_flag->{restart} ? "\n".
    "  else\n".
    "    frestart=1;\n".
    "    restart=\$(first \$(ls -1t $restart_name));\n".
    "    if [ ! -e \"\${restart}\" ]; then\n".
    "      printf \"# $restart_name does not exist -> skipped\\n\\n\";\n".
    "      run cd \${WORKDIR};\n".
    "      return;\n".
    "    fi;\n".
    "    restart=\"-file \\\"'ls -1td $restart_name'\\\"\";" : "";
  my $shear_line = $global->{shear}->{rate} ? "\n      -var framp ".(
      $global->{shear}->{ramp} eq "" ? 0 : $global->{shear}->{ramp} eq "false" ? 0 : 1)." \\" : "";
  my $run_line = $flag->{trun} ?
      ($context->{trun} ne "" ? "\n\t-var trun ".eval($context->{trun})." \\" : "") : "";

  printf($stream
"run_md() {
  local dir=\"\$1\"; shift;
  local frestart=\"\$1\"; shift;
  local ncores=\"\$1\"; shift;

  printf \"### \${dir}\\n\\n\";
  if [ ! -e \${dir} ]; then
    run mkdir -p \${dir};
  fi;

  local source=\"\$(path \"\${dir}\")\";
  local build=\"\$(path \"\${dir}/../build\")\";
  local restart_dir=\"\$(path ".(
    $md_flag->{restart} ? "$restart_dir" : "\${dir}/..").")\";
  local output restart file;
  
  if [ \${fbuild} != 1 ]; then
    if [ ! -e \${build}/$project_name.data ]; then
      printf \"# ../build/$project_name.data does not exists -> skipped\\n\\n\";
      run_null;
      return;
    fi;
    if [ ! -e \${build}/$project_name.params ]; then
      printf \"# ../build/$project_name.params does not exists -> skipped\\n\\n\";
      run_null;
      return;
    fi;
    if [ ! -e \${build}/$project_name.in ]; then
      printf \"# ../build/$project_name.in does not exists -> skipped\\n\\n\";
      run_null;
      return;
    fi;
  fi;

  if [ \${freplace} != 1 ]; then
    if [ \${frestart} != 1 ]; then
      if [ -e \${dir}/$project_name.dump ]; then
	printf \"# $project_name.dump exists -> skipped\\n\\n\";
	run_null;
	return;
      fi;
    else
      restart=\"-file \${restart_dir}\'/*/*.restart?\'\";".
      $restart_file."
      if [ \${ferror} == 1 ]; then
	if [ -e \"\$(first \${restart_dir}/*/$project_name.out)\" ]; then
	  file=\$(first \$(ls -1t \${restart_dir}/*/$project_name.out));
	  if [ \"\$(grep ERROR \${file})\" != \"\" ]; then
	    run_null;
	    return;
	  fi;
	else
	  frestart=0;
	fi;
      fi;
    fi;
  fi;

  run cd \${dir};
  run cp \${restart_dir}/build/$project_name.in .;
  set -f;
  WALLTIME=\${RUN_WALLTIME};
  run_pack -n \${ncores} -dir \"\${dir}\" \"\${restart}\" \\
    -walltime \${RUN_WALLTIME} -starttime \${START_TIME} -queue \${QUEUE} \\
    -input \${source}/$project_name.in -output $project_name.out \\
    -project $project_name \\
      lmp_\${HOST} -nocite \\
	-var source \${restart_dir}/build \\".
	$run_line.$shear_line."
	-var frestart \${frestart} \\
	-var restart \@FILE \\
	-var lseed \$(substr \${SEED} -8) \\
	-var vseed \$(substr \$(calc \"\${SEED}+1\") -8);
  set +f;

  SEED=\$(calc \${SEED}+2);
  run cd \"\${WORKDIR}\";
  echo;
}

set_restart() {
  RESTART=(\$1/*/*.restart?);
  echo \"\${RESTART[0]}\";
}

"); 
}

